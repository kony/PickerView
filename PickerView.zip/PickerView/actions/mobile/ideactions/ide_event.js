
function p2kwiet341880914118_btnContinue_onClick_seq0(eventobject){

onclickBtnContinue.call(this);

};


function p2kwiet341880914133_pickOne_onSelection_seq0(eventobject,    component,    keyselected){

pickerviewselkeyvalues.call(this);

};


function p2kwiet341880914133_btnAdd_onClick_seq0(eventobject){

setNewData.call(this);

};

