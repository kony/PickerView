function p2kwiet341880914159_pickOne_onSelection_seq0(eventobject, component, keyselected) {
    return pickerviewselkeyvalues.call(this);
}