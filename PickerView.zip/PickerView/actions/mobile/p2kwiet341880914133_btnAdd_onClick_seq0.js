function p2kwiet341880914133_btnAdd_onClick_seq0(eventobject) {
    return setNewData.call(this);
}