function p2kwiet341880914146_btnContinue_onClick_seq0(eventobject) {
    return onclickBtnContinue.call(this);
}