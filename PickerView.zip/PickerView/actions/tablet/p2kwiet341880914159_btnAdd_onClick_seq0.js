function p2kwiet341880914159_btnAdd_onClick_seq0(eventobject) {
    return setNewData.call(this);
}