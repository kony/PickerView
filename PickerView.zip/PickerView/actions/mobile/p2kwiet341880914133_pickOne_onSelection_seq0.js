function p2kwiet341880914133_pickOne_onSelection_seq0(eventobject, component, keyselected) {
    return pickerviewselkeyvalues.call(this);
}