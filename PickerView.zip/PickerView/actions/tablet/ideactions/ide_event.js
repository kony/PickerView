
function p2kwiet341880914146_btnContinue_onClick_seq0(eventobject){

onclickBtnContinue.call(this);

};


function p2kwiet341880914159_pickOne_onSelection_seq0(eventobject,    component,    keyselected){

pickerviewselkeyvalues.call(this);

};


function p2kwiet341880914159_btnAdd_onClick_seq0(eventobject){

setNewData.call(this);

};

